package com.example.androidproyectounivalle;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.androidproyectounivalle.activities.ItemCrudActivity;
import com.example.androidproyectounivalle.adapters.MenuAdapter;
import com.example.androidproyectounivalle.models.MenuItem;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private GridView gridViewMenu;
    private MenuAdapter menuAdapter;
    private List<MenuItem> menuItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Inicializar GridView
        gridViewMenu = findViewById(R.id.gridViewMenu);

        // Crear opciones del menú
        initMenuItems();

        // Configurar adaptador
        menuAdapter = new MenuAdapter(this, menuItems);
        gridViewMenu.setAdapter(menuAdapter);

        // Evento de clic
        gridViewMenu.setOnItemClickListener((parent, view, position, id) -> handleMenuSelection(position));
    }

    private void initMenuItems() {
        menuItems = new ArrayList<>();
        menuItems.add(new MenuItem("CRUD Vehículos", android.R.drawable.ic_menu_edit));
    }

    private void handleMenuSelection(int position) {
        if (position == 0) {
            Intent intent = new Intent(this, ItemCrudActivity.class);
            startActivity(intent);
        } else {
            Toast.makeText(this, "Opción no implementada aún", Toast.LENGTH_SHORT).show();
        }
    }
}
