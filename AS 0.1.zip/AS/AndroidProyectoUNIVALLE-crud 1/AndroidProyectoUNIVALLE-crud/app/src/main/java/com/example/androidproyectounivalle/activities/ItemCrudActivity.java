package com.example.androidproyectounivalle.activities;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.example.androidproyectounivalle.R;
import com.example.androidproyectounivalle.adapters.ItemCrudAdapter;
import com.example.androidproyectounivalle.models.Item;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.json.JSONArray;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class ItemCrudActivity extends AppCompatActivity implements ItemCrudAdapter.OnItemCrudListener {

    private RecyclerView recyclerView;
    private FloatingActionButton fab;
    private ItemCrudAdapter adapter;
    private List<Item> itemList = new ArrayList<>();
    private static final int REQUEST_CODE_FORM = 1;
    private static final String API_URL = "https://raw.githubusercontent.com/adancondori/TareaAPI/refs/heads/main/api/vehiculos.json";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_crud);

        recyclerView = findViewById(R.id.recyclerViewItems);
        fab = findViewById(R.id.fabAddItem);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ItemCrudAdapter(this, itemList, this);
        recyclerView.setAdapter(adapter);

        fab.setOnClickListener(v -> {
            Intent intent = new Intent(this, ItemFormActivity.class);
            startActivityForResult(intent, REQUEST_CODE_FORM);
        });

        cargarDatosDesdeAPI();
    }

    private void cargarDatosDesdeAPI() {
        RequestQueue queue = Volley.newRequestQueue(this);
        JsonArrayRequest request = new JsonArrayRequest(Request.Method.GET, API_URL, null,
                response -> {
                    Gson gson = new Gson();
                    Type listType = new TypeToken<List<Item>>() {}.getType();
                    List<Item> items = gson.fromJson(response.toString(), listType);
                    itemList.clear();
                    itemList.addAll(items);
                    adapter.notifyDataSetChanged();
                },
                error -> Toast.makeText(this, "Error al cargar API", Toast.LENGTH_SHORT).show()
        );
        queue.add(request);
    }

    @Override
    public void onEditClick(Item item, int position) {
        Intent intent = new Intent(this, ItemFormActivity.class);
        intent.putExtra("item", new Gson().toJson(item));
        intent.putExtra("position", position);
        startActivityForResult(intent, REQUEST_CODE_FORM);
    }

    @Override
    public void onDeleteClick(Item item, int position) {
        new AlertDialog.Builder(this)
                .setTitle("Eliminar")
                .setMessage("¿Seguro que deseas eliminar este elemento?")
                .setPositiveButton("Sí", (dialog, which) -> {
                    itemList.remove(position);
                    adapter.notifyItemRemoved(position);
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    @Override
    public void onItemClick(Item item, int position) {
        Intent intent = new Intent(this, ItemDetailActivity.class);
        intent.putExtra("item", new Gson().toJson(item));
        startActivity(intent);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CODE_FORM && resultCode == RESULT_OK && data != null) {
            String json = data.getStringExtra("item");
            int position = data.getIntExtra("position", -1);
            Item nuevoItem = new Gson().fromJson(json, Item.class);

            if (position >= 0) {
                itemList.set(position, nuevoItem);
                adapter.notifyItemChanged(position);
            } else {
                itemList.add(nuevoItem);
                adapter.notifyItemInserted(itemList.size() - 1);
            }
        }
    }
}
