package com.example.androidproyectounivalle.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import com.example.androidproyectounivalle.R;
import com.example.androidproyectounivalle.models.Item;
import com.google.gson.Gson;

public class ItemFormActivity extends AppCompatActivity {

    private EditText etMarca, etModelo, etAnio, etPrecio, etKilometraje, etTipo;
    private Button btnGuardar;

    private Item editItem;
    private int editPosition = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_form);

        etMarca = findViewById(R.id.etMarca);
        etModelo = findViewById(R.id.etModelo);
        etAnio = findViewById(R.id.etAnio);
        etPrecio = findViewById(R.id.etPrecio);
        etKilometraje = findViewById(R.id.etKilometraje);
        etTipo = findViewById(R.id.etTipo);
        btnGuardar = findViewById(R.id.btnGuardar);

        if (getIntent().hasExtra("item")) {
            String json = getIntent().getStringExtra("item");
            editItem = new Gson().fromJson(json, Item.class);
            editPosition = getIntent().getIntExtra("position", -1);
            cargarDatos(editItem);
        }

        btnGuardar.setOnClickListener(v -> {
            Item nuevo = new Item(); // usamos un setter-free versión
            nuevo.setMarca(etMarca.getText().toString());
            nuevo.setModelo(etModelo.getText().toString());
            nuevo.setAnioFabricacion(Integer.parseInt(etAnio.getText().toString()));
            nuevo.setPrecioBase(Double.parseDouble(etPrecio.getText().toString()));
            nuevo.setKilometraje(Double.parseDouble(etKilometraje.getText().toString()));
            nuevo.setTipo(etTipo.getText().toString());

            Intent result = new Intent();
            result.putExtra("item", new Gson().toJson(nuevo));
            result.putExtra("position", editPosition);
            setResult(RESULT_OK, result);
            finish();
        });
    }

    private void cargarDatos(Item item) {
        etMarca.setText(item.getMarca());
        etModelo.setText(item.getModelo());
        etAnio.setText(String.valueOf(item.getAnioFabricacion()));
        etPrecio.setText(String.valueOf(item.getPrecioBase()));
        etKilometraje.setText(String.valueOf(item.getKilometraje()));
        etTipo.setText(item.getTipo());
    }
}
