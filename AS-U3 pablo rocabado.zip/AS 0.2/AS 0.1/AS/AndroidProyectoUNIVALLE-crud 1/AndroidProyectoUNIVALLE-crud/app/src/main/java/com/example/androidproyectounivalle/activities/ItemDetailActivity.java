package com.example.androidproyectounivalle.activities;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.androidproyectounivalle.R;
import com.example.androidproyectounivalle.models.Item;
import com.google.gson.Gson;

public class ItemDetailActivity extends AppCompatActivity {

    private TextView tvMarca, tvModelo, tvAnio, tvPrecio, tvKilometraje, tvTipo, tvEstado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_detail);

        tvMarca = findViewById(R.id.tvMarca);
        tvModelo = findViewById(R.id.tvModelo);
        tvAnio = findViewById(R.id.tvAnio);
        tvPrecio = findViewById(R.id.tvPrecio);
        tvKilometraje = findViewById(R.id.tvKilometraje);
        tvTipo = findViewById(R.id.tvTipo);
        tvEstado = findViewById(R.id.tvEstado);

        Intent intent = getIntent();
        if (intent != null) {
            String json = intent.getStringExtra("item");
            Item item = new Gson().fromJson(json, Item.class);

            tvMarca.setText("Marca: " + item.getMarca());
            tvModelo.setText("Modelo: " + item.getModelo());
            tvAnio.setText("Año: " + item.getAnioFabricacion());
            tvPrecio.setText("Precio: $" + item.getPrecioBase());
            tvKilometraje.setText("Kilometraje: " + item.getKilometraje() + " km");
            tvTipo.setText("Tipo: " + item.getTipo());
            
            // Update status display
            if (item.isActive()) {
                tvEstado.setText("Estado: Activo");
                tvEstado.setTextColor(Color.parseColor("#4CAF50")); // Green color
            } else {
                tvEstado.setText("Estado: Inactivo");
                tvEstado.setTextColor(Color.parseColor("#F44336")); // Red color
            }
        }
    }
}
