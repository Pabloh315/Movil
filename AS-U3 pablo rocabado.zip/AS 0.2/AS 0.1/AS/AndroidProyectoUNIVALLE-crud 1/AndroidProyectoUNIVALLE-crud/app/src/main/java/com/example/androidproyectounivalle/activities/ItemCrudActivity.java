package com.example.androidproyectounivalle.activities;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.androidproyectounivalle.R;
import com.example.androidproyectounivalle.adapters.ItemCrudAdapter;
import com.example.androidproyectounivalle.models.Item;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class ItemCrudActivity extends AppCompatActivity implements ItemCrudAdapter.OnItemCrudListener {

    private RecyclerView recyclerView;
    private FloatingActionButton fab;
    private ItemCrudAdapter adapter;
    private List<Item> itemList = new ArrayList<>();
    private static final int REQUEST_CODE_FORM = 1;
    private static final String API_URL = "https://raw.githubusercontent.com/adancondori/TareaAPI/main/api/vehiculos.json";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_crud);

        recyclerView = findViewById(R.id.recyclerViewItems);
        fab = findViewById(R.id.fabAddItem);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ItemCrudAdapter(this, itemList, this);
        recyclerView.setAdapter(adapter);

        fab.setOnClickListener(v -> {
            Intent intent = new Intent(this, ItemFormActivity.class);
            startActivityForResult(intent, REQUEST_CODE_FORM);
        });

        cargarDatosDesdeAPI();
    }

    private void cargarDatosDesdeAPI() {
        RequestQueue queue = Volley.newRequestQueue(this);

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, API_URL, null,
                response -> {
                    try {
                        JSONArray vehiculosArray = response.getJSONArray("vehiculos");
                        List<Item> items = new ArrayList<>();

                        for (int i = 0; i < vehiculosArray.length(); i++) {
                            JSONObject vehiculo = vehiculosArray.getJSONObject(i);
                            Item item = new Item(
                                vehiculo.getString("marca"),
                                vehiculo.getString("modelo"),
                                vehiculo.getInt("anioFabricacion"),
                                vehiculo.getDouble("precioBase"),
                                vehiculo.getDouble("kilometraje"),
                                vehiculo.getString("tipo")
                            );
                            items.add(item);
                        }

                        itemList.clear();
                        itemList.addAll(items);
                        adapter.notifyDataSetChanged();
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(this, "Error al procesar datos de la API", Toast.LENGTH_LONG).show();
                    }
                },
                error -> {
                    error.printStackTrace();
                    Toast.makeText(this, "Error al cargar API: " + error.getMessage(), Toast.LENGTH_LONG).show();
                }
        );

        queue.add(request);
    }

    @Override
    public void onEditClick(Item item, int position) {
        try {
            Intent intent = new Intent(this, ItemFormActivity.class);
            intent.putExtra("item", new Gson().toJson(item));
            intent.putExtra("position", position);
            startActivityForResult(intent, REQUEST_CODE_FORM);
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Error al editar el elemento", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onDeleteClick(Item item, int position) {
        try {
            new AlertDialog.Builder(this)
                    .setTitle("Eliminar")
                    .setMessage("¿Seguro que deseas eliminar este elemento?")
                    .setPositiveButton("Sí", (dialog, which) -> {
                        try {
                            itemList.remove(position);
                            adapter.notifyItemRemoved(position);
                            Toast.makeText(this, "Elemento eliminado", Toast.LENGTH_SHORT).show();
                        } catch (Exception e) {
                            e.printStackTrace();
                            Toast.makeText(this, "Error al eliminar el elemento", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .setNegativeButton("Cancelar", null)
                    .show();
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Error al mostrar el diálogo", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onItemClick(Item item, int position) {
        try {
            Intent intent = new Intent(this, ItemDetailActivity.class);
            intent.putExtra("item", new Gson().toJson(item));
            startActivity(intent);
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Error al mostrar detalles", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onStatusChange(Item item, int position, boolean isActive) {
        try {
            // Update the item's status in the list
            itemList.get(position).setActive(isActive);
            adapter.notifyItemChanged(position);
            
            // Show a toast message to confirm the status change
            String status = isActive ? "activado" : "desactivado";
            Toast.makeText(this, "Elemento " + status, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Error al cambiar el estado", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CODE_FORM && resultCode == RESULT_OK && data != null) {
            try {
                String json = data.getStringExtra("item");
                int position = data.getIntExtra("position", -1);
                Item nuevoItem = new Gson().fromJson(json, Item.class);

                if (position >= 0) {
                    // Preservar el estado activo/inactivo al editar
                    boolean estadoAnterior = itemList.get(position).isActive();
                    nuevoItem.setActive(estadoAnterior);
                    itemList.set(position, nuevoItem);
                    adapter.notifyItemChanged(position);
                } else {
                    itemList.add(nuevoItem);
                    adapter.notifyItemInserted(itemList.size() - 1);
                }
                Toast.makeText(this, "Datos guardados correctamente", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(this, "Error al guardar los datos", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
