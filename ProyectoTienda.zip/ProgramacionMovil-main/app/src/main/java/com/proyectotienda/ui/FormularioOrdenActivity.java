package com.proyectotienda.ui;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import com.proyectotienda.R;
import com.proyectotienda.data.entities.Cliente;
import com.proyectotienda.data.entities.Orden;
import com.proyectotienda.data.entities.Producto;
import com.proyectotienda.viewmodel.ClienteViewModel;
import com.proyectotienda.viewmodel.OrdenViewModel;
import com.proyectotienda.viewmodel.ProductoViewModel;
import java.util.List;
import java.util.ArrayList;

public class FormularioOrdenActivity extends AppCompatActivity {
    private List<Cliente> clientesList = new ArrayList<>();
    private List<Producto> productosList = new ArrayList<>();

    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        setContentView(R.layout.activity_formulario_orden);

        Spinner spCliente = findViewById(R.id.spCliente);
        Spinner spProducto = findViewById(R.id.spProducto);
        Button btnGuardar = findViewById(R.id.btnGuardarOrden);
        Button btnCancelar = findViewById(R.id.btnCancelarOrden);

        ClienteViewModel cvm = new ViewModelProvider(this).get(ClienteViewModel.class);
        ProductoViewModel pvm = new ViewModelProvider(this).get(ProductoViewModel.class);
        OrdenViewModel ovm = new ViewModelProvider(this).get(OrdenViewModel.class);

        cvm.getAll().observe(this, clientes -> {
            if (clientes != null) {
                clientesList = clientes;
                if (clientes.isEmpty()) {
                    Toast.makeText(this, "No hay clientes registrados", Toast.LENGTH_LONG).show();
                    btnGuardar.setEnabled(false);
                } else {
                    List<String> nombres = clientes.stream()
                            .map(c -> c.nombre)
                            .toList();
                    spCliente.setAdapter(new ArrayAdapter<>(this,
                            android.R.layout.simple_spinner_dropdown_item, nombres));
                    btnGuardar.setEnabled(true);
                }
            }
        });

        pvm.getAll().observe(this, productos -> {
            if (productos != null) {
                productosList = productos;
                if (productos.isEmpty()) {
                    Toast.makeText(this, "No hay productos registrados", Toast.LENGTH_LONG).show();
                    btnGuardar.setEnabled(false);
                } else {
                    List<String> listP = productos.stream()
                            .map(p -> p.nombre)
                            .toList();
                    spProducto.setAdapter(new ArrayAdapter<>(this,
                            android.R.layout.simple_spinner_dropdown_item, listP));
                    btnGuardar.setEnabled(true);
                }
            }
        });

        btnGuardar.setOnClickListener(v -> {
            if (clientesList.isEmpty() || productosList.isEmpty()) {
                Toast.makeText(this, "No hay datos suficientes para crear la orden", Toast.LENGTH_LONG).show();
                return;
            }

            if (spCliente.getSelectedItemPosition() >= 0 && spProducto.getSelectedItemPosition() >= 0) {
                try {
                    Orden o = new Orden();
                    o.fecha = java.time.LocalDate.now().toString();
                    o.hora = java.time.LocalTime.now()
                            .withSecond(0).withNano(0).toString();
                    o.clienteId = clientesList.get(spCliente.getSelectedItemPosition()).id;
                    o.productoId = productosList.get(spProducto.getSelectedItemPosition()).id;
                    ovm.insert(o);
                    Toast.makeText(this, "Orden creada exitosamente", Toast.LENGTH_SHORT).show();
                    finish();
                } catch (Exception e) {
                    Toast.makeText(this, "Error al crear la orden: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            } else {
                Toast.makeText(this, "Por favor seleccione un cliente y un producto", Toast.LENGTH_LONG).show();
            }
        });

        btnCancelar.setOnClickListener(v -> finish());
    }
}
