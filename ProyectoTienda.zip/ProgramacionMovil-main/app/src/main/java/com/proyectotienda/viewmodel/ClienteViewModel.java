package com.proyectotienda.viewmodel;

import android.app.Application;
import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import com.proyectotienda.data.entities.Cliente;
import com.proyectotienda.repository.ClienteRepository;
import java.util.List;

public class ClienteViewModel extends AndroidViewModel {
    private final ClienteRepository repo;
    public ClienteViewModel(@NonNull Application app) {
        super(app);
        repo = new ClienteRepository(app);
    }
    public LiveData<List<Cliente>> getAll() { return repo.getAll(); }
    public void insert(Cliente c) { repo.insert(c); }
    public void delete(Cliente c) { repo.delete(c); }
}