package com.proyectotienda.ui;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.proyectotienda.R;

public class MainActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        setContentView(R.layout.activity_main);

        findViewById(R.id.btnClientes).setOnClickListener(v ->
                startActivity(new Intent(this, ListadoClientesActivity.class)));

        findViewById(R.id.btnProductos).setOnClickListener(v ->
                startActivity(new Intent(this, ListadoProductosActivity.class)));

        findViewById(R.id.btnOrdenes).setOnClickListener(v ->
                startActivity(new Intent(this, ListadoOrdenesActivity.class)));
    }
}
