package com.proyectotienda.data.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import com.proyectotienda.data.entities.Cliente;
import java.util.List;

@Dao
public interface ClienteDao {
    @Query("SELECT * FROM Cliente")
    LiveData<List<Cliente>> getAll();

    @Insert
    long insert(Cliente cliente);

    @Delete
    void delete(Cliente cliente);

    @Query("DELETE FROM Cliente")
    void deleteAll();
}
