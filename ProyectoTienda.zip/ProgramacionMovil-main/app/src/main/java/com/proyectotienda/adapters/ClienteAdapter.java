package com.proyectotienda.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.proyectotienda.R;
import com.proyectotienda.data.entities.Cliente;
import java.util.List;

public class ClienteAdapter extends RecyclerView.Adapter<ClienteAdapter.Holder> {
    private final List<Cliente> items;
    public ClienteAdapter(List<Cliente> items) { this.items = items; }
    @Override public Holder onCreateViewHolder(ViewGroup p, int vt) {
        return new Holder(LayoutInflater.from(p.getContext())
                .inflate(R.layout.item_cliente, p, false));
    }
    @Override public void onBindViewHolder(Holder h, int pos) {
        Cliente c = items.get(pos);
        h.tvName.setText(c.nombre + " (" + c.email + ")");
    }
    @Override public int getItemCount() { return items.size(); }
    static class Holder extends RecyclerView.ViewHolder {
        TextView tvName;
        Holder(View v) { super(v); tvName = v.findViewById(R.id.tvClienteName); }
    }
}
