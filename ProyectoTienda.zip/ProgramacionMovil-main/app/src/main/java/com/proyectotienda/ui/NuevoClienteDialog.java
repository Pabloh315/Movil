package com.proyectotienda.ui;

import android.app.Dialog;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;
import androidx.lifecycle.ViewModelProvider;
import android.view.LayoutInflater;
import android.util.Patterns;
import android.widget.Toast;
import com.proyectotienda.R;
import com.proyectotienda.data.entities.Cliente;
import com.proyectotienda.viewmodel.ClienteViewModel;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.button.MaterialButton;
import java.util.regex.Pattern;

public class NuevoClienteDialog extends DialogFragment {
    private static final int MAX_NOMBRE_LENGTH = 100;
    private static final Pattern NOMBRE_PATTERN = Pattern.compile("^[\\p{L} .'-]+$");

    @NonNull @Override 
    public Dialog onCreateDialog(Bundle s) {
        ClienteViewModel vm = new ViewModelProvider(requireActivity()).get(ClienteViewModel.class);
        var v = LayoutInflater.from(getContext())
                .inflate(R.layout.dialog_nuevo_cliente, null);

        TextInputEditText etNombre = v.findViewById(R.id.etClienteNombre);
        TextInputEditText etTel = v.findViewById(R.id.etClienteTelefono);
        TextInputEditText etMail = v.findViewById(R.id.etClienteEmail);
        MaterialButton btnGuardar = v.findViewById(R.id.btnGuardar);
        MaterialButton btnCancelar = v.findViewById(R.id.btnCancelar);

        AlertDialog dialog = new AlertDialog.Builder(requireContext())
                .setView(v)
                .create();

        btnGuardar.setOnClickListener(view -> {
            String nombre = etNombre.getText().toString().trim();
            String telefono = etTel.getText().toString().trim();
            String email = etMail.getText().toString().trim();

            if (nombre.isEmpty()) {
                etNombre.setError("El nombre es requerido");
                return;
            }

            if (nombre.length() > MAX_NOMBRE_LENGTH) {
                etNombre.setError("El nombre no puede tener más de " + MAX_NOMBRE_LENGTH + " caracteres");
                return;
            }

            if (!NOMBRE_PATTERN.matcher(nombre).matches()) {
                etNombre.setError("El nombre solo puede contener letras, espacios y los caracteres .'-");
                return;
            }

            if (telefono.isEmpty()) {
                etTel.setError("El teléfono es requerido");
                return;
            }

            if (!telefono.matches("\\d{10}")) {
                etTel.setError("El teléfono debe tener 10 dígitos");
                return;
            }

            if (email.isEmpty()) {
                etMail.setError("El email es requerido");
                return;
            }

            if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                etMail.setError("Formato de email inválido");
                return;
            }

            try {
                Cliente c = new Cliente();
                c.nombre = nombre;
                c.telefono = telefono;
                c.email = email;
                vm.insert(c);
                Toast.makeText(getContext(), "Cliente guardado exitosamente", Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            } catch (Exception e) {
                Toast.makeText(getContext(), "Error al guardar el cliente: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        });

        btnCancelar.setOnClickListener(v2 -> dialog.dismiss());

        return dialog;
    }
}
