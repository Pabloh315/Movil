package com.proyectotienda.viewmodel;

import android.app.Application;
import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import com.proyectotienda.data.entities.Orden;
import com.proyectotienda.data.entities.OrdenConDetalles;
import com.proyectotienda.repository.OrdenRepository;
import java.util.List;

public class OrdenViewModel extends AndroidViewModel {
    private final OrdenRepository repo;
    public OrdenViewModel(@NonNull Application app) {
        super(app);
        repo = new OrdenRepository(app);
    }
    public LiveData<List<OrdenConDetalles>> getAllWithDetails() { return repo.getAllWithDetails(); }
    public void insert(Orden o) { repo.insert(o); }
    public void delete(Orden o) { repo.delete(o); }
}