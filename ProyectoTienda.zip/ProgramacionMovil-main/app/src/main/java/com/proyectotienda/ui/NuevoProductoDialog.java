package com.proyectotienda.ui;

import android.app.Dialog;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;
import androidx.lifecycle.ViewModelProvider;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Toast;
import com.proyectotienda.R;
import com.proyectotienda.data.entities.Producto;
import com.proyectotienda.viewmodel.ProductoViewModel;
import com.google.android.material.textfield.TextInputEditText;
import java.text.DecimalFormat;
import java.text.ParseException;

public class NuevoProductoDialog extends DialogFragment {
    private static final int MAX_NOMBRE_LENGTH = 100;
    private static final int MAX_DESCRIPCION_LENGTH = 500;
    private static final DecimalFormat PRICE_FORMAT = new DecimalFormat("#,##0.00");

    @NonNull @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        ProductoViewModel vm = new ViewModelProvider(requireActivity())
                .get(ProductoViewModel.class);

        View v = LayoutInflater.from(getContext())
                .inflate(R.layout.dialog_nuevo_producto, null);

        TextInputEditText etNombre = v.findViewById(R.id.etProductoNombre);
        TextInputEditText etDescripcion = v.findViewById(R.id.etProductoDescripcion);
        TextInputEditText etPrecio = v.findViewById(R.id.etProductoPrecio);

        AlertDialog dialog = new AlertDialog.Builder(requireContext())
                .setTitle("Nuevo Producto")
                .setView(v)
                .setPositiveButton("Guardar", null)
                .setNegativeButton("Cancelar", null)
                .create();

        dialog.setOnShowListener(dialogInterface -> {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(view -> {
                String nombre = etNombre.getText().toString().trim();
                String descripcion = etDescripcion.getText().toString().trim();
                String precioStr = etPrecio.getText().toString().trim();

                if (nombre.isEmpty()) {
                    etNombre.setError("El nombre es requerido");
                    return;
                }

                if (nombre.length() > MAX_NOMBRE_LENGTH) {
                    etNombre.setError("El nombre no puede tener más de " + MAX_NOMBRE_LENGTH + " caracteres");
                    return;
                }

                if (descripcion.isEmpty()) {
                    etDescripcion.setError("La descripción es requerida");
                    return;
                }

                if (descripcion.length() > MAX_DESCRIPCION_LENGTH) {
                    etDescripcion.setError("La descripción no puede tener más de " + MAX_DESCRIPCION_LENGTH + " caracteres");
                    return;
                }

                if (precioStr.isEmpty()) {
                    etPrecio.setError("El precio es requerido");
                    return;
                }

                try {
                    double precio = PRICE_FORMAT.parse(precioStr).doubleValue();
                    if (precio <= 0) {
                        etPrecio.setError("El precio debe ser mayor a 0");
                        return;
                    }

                    if (precio > 999999.99) {
                        etPrecio.setError("El precio no puede ser mayor a 999,999.99");
                        return;
                    }

                    Producto p = new Producto();
                    p.nombre = nombre;
                    p.descripcion = descripcion;
                    p.precio = precio;
                    
                    try {
                        vm.insert(p);
                        Toast.makeText(getContext(), "Producto guardado exitosamente", Toast.LENGTH_SHORT).show();
                        dialog.dismiss();
                    } catch (Exception e) {
                        Toast.makeText(getContext(), "Error al guardar el producto: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                } catch (ParseException e) {
                    etPrecio.setError("Formato de precio inválido. Use el formato: 0.00");
                }
            });
        });

        return dialog;
    }
}
