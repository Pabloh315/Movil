package com.proyectotienda.viewmodel;

import android.app.Application;
import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import com.proyectotienda.data.entities.Producto;
import com.proyectotienda.repository.ProductoRepository;
import java.util.List;

public class ProductoViewModel extends AndroidViewModel {
    private final ProductoRepository repo;
    public ProductoViewModel(@NonNull Application app) {
        super(app);
        repo = new ProductoRepository(app);
    }
    public LiveData<List<Producto>> getAll() { return repo.getAll(); }
    public void insert(Producto p) { repo.insert(p); }
    public void delete(Producto p) { repo.delete(p); }
}
