package com.proyectotienda.data.database;

import android.content.Context;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import com.proyectotienda.data.dao.ClienteDao;
import com.proyectotienda.data.dao.ProductoDao;
import com.proyectotienda.data.dao.OrdenDao;
import com.proyectotienda.data.entities.Cliente;
import com.proyectotienda.data.entities.Producto;
import com.proyectotienda.data.entities.Orden;

@Database(entities = {Cliente.class, Producto.class, Orden.class}, version = 1)
public abstract class AppDatabase extends RoomDatabase {
    private static AppDatabase INSTANCE;
    public abstract ClienteDao clienteDao();
    public abstract ProductoDao productoDao();
    public abstract OrdenDao ordenDao();

    public static synchronized AppDatabase getInstance(Context ctx) {
        if (INSTANCE == null) {
            INSTANCE = Room.databaseBuilder(ctx.getApplicationContext(),
                            AppDatabase.class, "tienda_db")
                    .fallbackToDestructiveMigration()
                    .build();
        }
        return INSTANCE;
    }
}
