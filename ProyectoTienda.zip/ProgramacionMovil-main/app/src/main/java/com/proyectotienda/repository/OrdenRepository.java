package com.proyectotienda.repository;

import android.app.Application;
import androidx.lifecycle.LiveData;
import com.proyectotienda.data.dao.OrdenDao;
import com.proyectotienda.data.entities.Orden;
import com.proyectotienda.data.entities.OrdenConDetalles;
import com.proyectotienda.data.database.AppDatabase;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class OrdenRepository {
    private final OrdenDao dao;
    private final ExecutorService exe = Executors.newSingleThreadExecutor();
    public OrdenRepository(Application app) {
        dao = AppDatabase.getInstance(app).ordenDao();
    }
    public LiveData<List<OrdenConDetalles>> getAllWithDetails() { return dao.getAllWithDetails(); }
    public void insert(Orden o) { exe.execute(() -> dao.insert(o)); }
    public void delete(Orden o) { exe.execute(() -> dao.delete(o)); }
}