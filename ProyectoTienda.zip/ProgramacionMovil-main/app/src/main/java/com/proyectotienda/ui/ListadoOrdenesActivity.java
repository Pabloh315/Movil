package com.proyectotienda.ui;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.proyectotienda.R;
import com.proyectotienda.adapters.OrdenAdapter;
import com.proyectotienda.viewmodel.OrdenViewModel;

public class ListadoOrdenesActivity extends AppCompatActivity {
    private OrdenViewModel vm;

    @Override 
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        setContentView(R.layout.activity_listado_ordenes);

        RecyclerView rv = findViewById(R.id.rvOrdenes);
        rv.setLayoutManager(new LinearLayoutManager(this));
        
        vm = new ViewModelProvider(this).get(OrdenViewModel.class);
        vm.getAllWithDetails().observe(this, ods ->
                rv.setAdapter(new OrdenAdapter(ods))
        );

        findViewById(R.id.fabAddOrden).setOnClickListener(v ->
                startActivity(new Intent(this, FormularioOrdenActivity.class))
        );
    }
}
