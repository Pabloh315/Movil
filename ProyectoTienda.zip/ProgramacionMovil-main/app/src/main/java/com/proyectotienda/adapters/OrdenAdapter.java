package com.proyectotienda.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.proyectotienda.R;
import com.proyectotienda.data.entities.OrdenConDetalles;
import java.util.List;

public class OrdenAdapter extends RecyclerView.Adapter<OrdenAdapter.Holder> {
    private final List<OrdenConDetalles> items;
    public OrdenAdapter(List<OrdenConDetalles> items) { this.items = items; }
    @Override public Holder onCreateViewHolder(ViewGroup p, int vt) {
        return new Holder(LayoutInflater.from(p.getContext())
                .inflate(R.layout.item_orden, p, false));
    }
    @Override public void onBindViewHolder(Holder h, int pos) {
        OrdenConDetalles od = items.get(pos);
        h.tvInfo.setText(
                od.orden.fecha + " " + od.orden.hora +
                        " | " + od.cliente.nombre +
                        " → " + od.producto.nombre
        );
    }
    @Override public int getItemCount() { return items.size(); }
    static class Holder extends RecyclerView.ViewHolder {
        TextView tvInfo;
        Holder(View v) { super(v); tvInfo = v.findViewById(R.id.tvOrdenInfo); }
    }
}