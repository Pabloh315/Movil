package com.proyectotienda.data.entities;

import androidx.room.Embedded;
import androidx.room.Relation;

public class OrdenConDetalles {
    @Embedded public Orden orden;
    @Relation(parentColumn = "clienteId", entityColumn = "id")
    public Cliente cliente;
    @Relation(parentColumn = "productoId", entityColumn = "id")
    public Producto producto;
}
