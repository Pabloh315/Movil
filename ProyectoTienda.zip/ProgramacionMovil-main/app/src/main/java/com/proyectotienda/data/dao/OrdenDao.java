package com.proyectotienda.data.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Transaction;
import com.proyectotienda.data.entities.Orden;
import com.proyectotienda.data.entities.OrdenConDetalles;
import java.util.List;

@Dao
public interface OrdenDao {
    @Transaction
    @Query("SELECT * FROM Orden")
    LiveData<List<OrdenConDetalles>> getAllWithDetails();

    @Insert
    long insert(Orden orden);

    @Delete
    void delete(Orden orden);

    @Query("DELETE FROM Orden")
    void deleteAll();
}
