package com.proyectotienda.repository;

import android.app.Application;
import androidx.lifecycle.LiveData;
import com.proyectotienda.data.dao.ClienteDao;
import com.proyectotienda.data.database.AppDatabase;
import com.proyectotienda.data.entities.Cliente;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ClienteRepository {
    private final ClienteDao dao;
    private final ExecutorService exe = Executors.newSingleThreadExecutor();
    public ClienteRepository(Application app) {
        dao = AppDatabase.getInstance(app).clienteDao();
    }
    public LiveData<List<Cliente>> getAll() { return dao.getAll(); }
    public void insert(Cliente c) { exe.execute(() -> dao.insert(c)); }
    public void delete(Cliente c) { exe.execute(() -> dao.delete(c)); }
}