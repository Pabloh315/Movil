package com.proyectotienda.ui;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.proyectotienda.R;
import com.proyectotienda.adapters.ProductoAdapter;
import com.proyectotienda.viewmodel.ProductoViewModel;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class ListadoProductosActivity extends AppCompatActivity {
    private ProductoViewModel vm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listado_productos);

        RecyclerView rv = findViewById(R.id.rvProductos);
        rv.setLayoutManager(new LinearLayoutManager(this));

        vm = new ViewModelProvider(this).get(ProductoViewModel.class);
        vm.getAll().observe(this, productos ->
                rv.setAdapter(new ProductoAdapter(productos))
        );

        FloatingActionButton fab = findViewById(R.id.fabAddProducto);
        fab.setOnClickListener(v ->
                new NuevoProductoDialog().show(getSupportFragmentManager(), null)
        );
    }
}
