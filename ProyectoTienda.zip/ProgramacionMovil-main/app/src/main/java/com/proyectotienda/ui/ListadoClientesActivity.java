package com.proyectotienda.ui;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.proyectotienda.R;
import com.proyectotienda.adapters.ClienteAdapter;
import com.proyectotienda.viewmodel.ClienteViewModel;

public class ListadoClientesActivity extends AppCompatActivity {
    private ClienteViewModel vm;
    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        setContentView(R.layout.activity_listado_clientes);

        RecyclerView rv = findViewById(R.id.rvClientes);
        rv.setLayoutManager(new LinearLayoutManager(this));
        vm = new ViewModelProvider(this).get(ClienteViewModel.class);
        vm.getAll().observe(this, clientes ->
                rv.setAdapter(new ClienteAdapter(clientes))
        );

        findViewById(R.id.fabAddCliente).setOnClickListener(v ->
                new NuevoClienteDialog().show(getSupportFragmentManager(), null)
        );
    }
}
