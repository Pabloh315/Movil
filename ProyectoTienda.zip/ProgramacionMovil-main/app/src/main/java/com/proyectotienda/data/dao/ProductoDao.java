package com.proyectotienda.data.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import com.proyectotienda.data.entities.Producto;
import java.util.List;

@Dao
public interface ProductoDao {
    @Query("SELECT * FROM Producto")
    LiveData<List<Producto>> getAll();

    @Insert
    long insert(Producto producto);

    @Delete
    void delete(Producto producto);

    @Query("DELETE FROM Producto")
    void deleteAll();
}
