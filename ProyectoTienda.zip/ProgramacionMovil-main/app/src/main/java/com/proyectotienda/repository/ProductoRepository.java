package com.proyectotienda.repository;

import android.app.Application;
import androidx.lifecycle.LiveData;
import com.proyectotienda.data.dao.ProductoDao;
import com.proyectotienda.data.database.AppDatabase;
import com.proyectotienda.data.entities.Producto;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ProductoRepository {
    private final ProductoDao dao;
    private final ExecutorService exe = Executors.newSingleThreadExecutor();
    public ProductoRepository(Application app) {
        dao = AppDatabase.getInstance(app).productoDao();
    }
    public LiveData<List<Producto>> getAll() { return dao.getAll(); }
    public void insert(Producto p) { exe.execute(() -> dao.insert(p)); }
    public void delete(Producto p) { exe.execute(() -> dao.delete(p)); }
}