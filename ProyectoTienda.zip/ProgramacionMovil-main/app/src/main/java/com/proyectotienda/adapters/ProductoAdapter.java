package com.proyectotienda.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.proyectotienda.R;
import com.proyectotienda.data.entities.Producto;
import java.util.List;
import java.text.NumberFormat;
import java.util.Locale;

public class ProductoAdapter extends RecyclerView.Adapter<ProductoAdapter.Holder> {
    private final List<Producto> items;
    private final NumberFormat currencyFormat;

    public ProductoAdapter(List<Producto> items) {
        this.items = items;
        this.currencyFormat = NumberFormat.getCurrencyInstance(new Locale("es", "MX"));
    }

    @Override 
    public Holder onCreateViewHolder(ViewGroup p, int vt) {
        return new Holder(LayoutInflater.from(p.getContext())
                .inflate(R.layout.item_producto, p, false));
    }

    @Override 
    public void onBindViewHolder(Holder h, int pos) {
        Producto pr = items.get(pos);
        h.tvName.setText(pr.nombre);
        h.tvPrecio.setText(currencyFormat.format(pr.precio));
    }

    @Override 
    public int getItemCount() { 
        return items.size(); 
    }

    static class Holder extends RecyclerView.ViewHolder {
        TextView tvName;
        TextView tvPrecio;

        Holder(View v) { 
            super(v); 
            tvName = v.findViewById(R.id.tvProductoName);
            tvPrecio = v.findViewById(R.id.tvProductoPrecio);
        }
    }
}
