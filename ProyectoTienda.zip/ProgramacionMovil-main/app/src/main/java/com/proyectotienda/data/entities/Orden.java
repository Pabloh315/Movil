package com.proyectotienda.data.entities;

import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;

@Entity(foreignKeys = {
        @ForeignKey(entity = Cliente.class,
                parentColumns = "id",
                childColumns = "clienteId",
                onDelete = ForeignKey.CASCADE),
        @ForeignKey(entity = Producto.class,
                parentColumns = "id",
                childColumns = "productoId",
                onDelete = ForeignKey.CASCADE)
})
public class Orden {
    @PrimaryKey(autoGenerate = true)
    public int id;
    public String fecha;      // formateada como "yyyy-MM-dd"
    public String hora;       // "HH:mm"
    public int clienteId;
    public int productoId;
}
